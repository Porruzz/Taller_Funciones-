#include <iostream>

using namespace std;

int factorial(int n) {
    if (n == 0) {
        return 1;
    } else {
        return n * factorial(n - 1);
    }
}

int main() {
    int numeros[10];
    for (int i = 0; i < 10; i++) {
        cout << "Ingrese el numero " << i + 1 << ": ";
        cin >> numeros[i];
    }
    for (int i = 0; i < 10; i++) {
        cout << "El factorial de " << numeros[i] << " es " << factorial(numeros[i]) << endl;
    }
    return 0;
}