#include <iostream>

using namespace std;

float calcularSubsidio(float salarioMensual, int numHijos) {
    if (numHijos <= 2) {
        return salarioMensual * 0.05;
    } else {
        return salarioMensual * 0.03;
    }
}

int main() {
    float salarioMensual;
    int numHijos;

    cout << "Ingrese el salario mensual: ";
    cin >> salarioMensual;

    cout << "Ingrese el numero de hijos: ";
    cin >> numHijos;

    float subsidio = calcularSubsidio(salarioMensual, numHijos);

    cout << "El subsidio familiar es: " << subsidio << endl;

    return 0;
}