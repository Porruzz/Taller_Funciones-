#include <iostream>
#include <cmath>

using namespace std;

// Función para determinar si un número es par o impar
void parImpar(int num) {
    if (num % 2 == 0) {
        cout << num << " es un número par" << endl;
    } else {
        cout << num << " es un número impar" << endl;
    }
}

// Función para calcular el cuadrado o el cubo de un número
void calculo(int num) {
    if (num > 0 && num % 2 == 0) {
        cout << "El cuadrado de " << num << " es " << pow(num, 2) << endl;
    } else {
        cout << "El cubo de " << num << " es " << pow(num, 3) << endl;
    }
}

int main() {
    int num, opcion;

    cout << "Ingrese un número entero: ";
    cin >> num;

    cout << endl << "Menu de opciones" << endl;
    cout << "1. Par o Impar" << endl;
    cout << "2. Calculo" << endl;
    cout << "Digite opción: ";
    cin >> opcion;

    switch (opcion) {
        case 1:
            parImpar(num);
            break;
        case 2:
            calculo(num);
            break;
        default:
            cout << "Opción inválida" << endl;
            break;
    }

    return 0;
}