#include <iostream>
#include <cmath>
#include <string>

using namespace std;

// Funciones para las conversiones
string decimalToBinary(int decimal);
string decimalToOctal(int decimal);
string decimalToHexadecimal(int decimal);
int binaryToDecimal(string binary);
int octalToDecimal(int octal);
int hexadecimalToDecimal(string hexadecimal);

int main() {
    int opcion, decimal, octal;
    string binary, hexadecimal;

    do {
        // Mostrar el menú de opciones
        cout << "CONVERSIONES" << endl;
        cout << "1. Decimal a binario" << endl;
        cout << "2. Decimal a octal" << endl;
        cout << "3. Decimal a hexadecimal" << endl;
        cout << "4. Binario a decimal" << endl;
        cout << "5. Octal a decimal" << endl;
        cout << "6. Hexadecimal a decimal" << endl;
        cout << "0. Salir" << endl;
        cout << "Ingrese una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                // Pedir el número decimal
                cout << "Ingrese un numero decimal: ";
                cin >> decimal;
                // Convertir a binario y mostrar el resultado
                cout << "El numero en binario es: " << decimalToBinary(decimal) << endl;
                break;
            case 2:
                // Pedir el número decimal
                cout << "Ingrese un numero decimal: ";
                cin >> decimal;
                // Convertir a octal y mostrar el resultado
                cout << "El numero en octal es: " << decimalToOctal(decimal) << endl;
                break;
            case 3:
                // Pedir el número decimal
                cout << "Ingrese un numero decimal: ";
                cin >> decimal;
                // Convertir a hexadecimal y mostrar el resultado
                cout << "El numero en hexadecimal es: " << decimalToHexadecimal(decimal) << endl;
                break;
            case 4:
                // Pedir el número binario
                cout << "Ingrese un numero binario: ";
                cin >> binary;
                // Convertir a decimal y mostrar el resultado
                cout << "El numero en decimal es: " << binaryToDecimal(binary) << endl;
                break;
            case 5:
                // Pedir el número octal
                cout << "Ingrese un numero octal: ";
                cin >> octal;
                // Convertir a decimal y mostrar el resultado
                cout << "El numero en decimal es: " << octalToDecimal(octal) << endl;
                break;
            case 6:
                // Pedir el número hexadecimal
                cout << "Ingrese un numero hexadecimal: ";
                cin >> hexadecimal;
                // Convertir a decimal y mostrar el resultado
                cout << "El numero en decimal es: " << hexadecimalToDecimal(hexadecimal) << endl;
                break;
            case 0:
                // Salir del programa
                cout << "Saliendo del programa..." << endl;
                break;
            default:
                // Opción inválida
                cout << "Opcion invalida. Intente de nuevo." << endl;
                break;
        }
    } while (opcion != 0);

    return 0;
}

// Función para convertir un número decimal a binario
string decimalToBinary(int decimal) {
    string binary = "";
    while (decimal > 0) {
        binary = to_string(decimal % 2) + binary;
        decimal /= 2;
    }
    return binary;
}

// Función para convertir un número decimal a octal
string decimalToOctal(int decimal) {
    string octal = "";
    while (decimal > 0) {
        octal = to_string(decimal % 8) + octal;
        decimal /= 8;
    }
    return octal;
}

// Función para convertir un número decimal a hexadecimal
string decimalToHexadecimal(int decimal) {
    string hexadecimal = "";
    while (decimal > 0) {
        int remainder = decimal % 16;
        if (remainder < 10) {
            hexadecimal = to_string(remainder) + hexadecimal;
        } else {
            hexadecimal = char(remainder - 10 + 'A') + hexadecimal;
        }
        decimal /= 16;
    }
    return hexadecimal;
}

// Función para convertir un número binario a decimal
int binaryToDecimal(string binary) {
    int decimal = 0;
    int power = 0;
    for (int i = binary.length() - 1; i >= 0; i--) {
        if (binary[i] == '1') {
            decimal += pow(2, power);
        }
        power++;
    }
    return decimal;
}

// Funcion para convertir un numero octal a decimal
int octalToDecimal(int octal) {
    int decimal = 0;
    int power = 0;
    while (octal > 0) {
        decimal += (octal % 10) * pow(8, power);
        octal /= 10;
        power++;
    }
    return decimal;
}

int hexadecimalToDecimal(string hexadecimal) {
    int decimal = 0;
    int power = 0;
    for (int i = hexadecimal.length() - 1; i >= 0; i--) {
        if (hexadecimal[i] >= '0' && hexadecimal[i] <= '9') {
            decimal += (hexadecimal[i] - '0') * pow(16, power);
        } else if (hexadecimal[i] >= 'A' && hexadecimal[i] <= 'F') {
            decimal += (hexadecimal[i] - 'A' + 10) * pow(16, power);
        } else if (hexadecimal[i] >= 'a' && hexadecimal[i] <= 'f') {
            decimal += (hexadecimal[i] - 'a' + 10) * pow(16, power);
        }
        power++;
    }
    return decimal;
}
