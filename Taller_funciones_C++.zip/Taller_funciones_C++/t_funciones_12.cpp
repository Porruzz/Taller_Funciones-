#include <iostream>
using namespace std;

int calcularCantidadCanciones() {
    int espacioDisponible = 3 * 1024 * 1024; // Convertimos 3Gb a kilobytes
    int tamanoCancion = 4550; // Tamaño promedio de cada canción en kilobytes
    int cantidadCanciones = espacioDisponible / tamanoCancion;
    return cantidadCanciones;
}

int main() {
    int cantidadCanciones = calcularCantidadCanciones();
    cout << "La cantidad de canciones que se pueden almacenar es: " << cantidadCanciones << endl;
    return 0;
}