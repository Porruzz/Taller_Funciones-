#include <iostream>
#include <string>

using namespace std;

struct Estudiante {
    string codigo;
    float nota1;
    float nota2;
    float nota3;
    float notaDefinitiva;
};

void calcularNotaDefinitiva(Estudiante& estudiante) {
    estudiante.notaDefinitiva = estudiante.nota1 * 0.3 + estudiante.nota2 * 0.3 + estudiante.nota3 * 0.4;
}

int main() {
    int n;
    cout << "Ingrese el numero de estudiantes: ";
    cin >> n;

    Estudiante estudiantes[n];

    // Leer datos de los estudiantes
    for (int i = 0; i < n; i++) {
        cout << "Ingrese el codigo del estudiante " << i + 1 << ": ";
        cin >> estudiantes[i].codigo;
        cout << "Ingrese la nota 1 del estudiante " << i + 1 << ": ";
        cin >> estudiantes[i].nota1;
        cout << "Ingrese la nota 2 del estudiante " << i + 1 << ": ";
        cin >> estudiantes[i].nota2;
        cout << "Ingrese la nota 3 del estudiante " << i + 1 << ": ";
        cin >> estudiantes[i].nota3;

        calcularNotaDefinitiva(estudiantes[i]);
    }

    // Encontrar estudiante de mayor y menor rendimiento
    int indiceMayorRendimiento = 0;
    int indiceMenorRendimiento = 0;
    for (int i = 1; i < n; i++) {
        if (estudiantes[i].notaDefinitiva > estudiantes[indiceMayorRendimiento].notaDefinitiva) {
            indiceMayorRendimiento = i;
        }
        if (estudiantes[i].notaDefinitiva < estudiantes[indiceMenorRendimiento].notaDefinitiva) {
            indiceMenorRendimiento = i;
        }
    }

    // Mostrar resultados
    cout << endl;
    cout << "Estudiante de mayor rendimiento: " << estudiantes[indiceMayorRendimiento].codigo << " con nota definitiva de " << estudiantes[indiceMayorRendimiento].notaDefinitiva << endl;
    cout << "Estudiante de menor rendimiento: " << estudiantes[indiceMenorRendimiento].codigo << " con nota definitiva de " << estudiantes[indiceMenorRendimiento].notaDefinitiva << endl;

    return 0;
}