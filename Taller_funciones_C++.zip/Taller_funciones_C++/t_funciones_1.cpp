#include <iostream>

using namespace std;

// Función para ordenar tres números enteros en forma ascendente
void ordenar(int &a, int &b, int &c) {
    int temp;
    if (a > b) {
        temp = a;
        a = b;
        b = temp;
    }
    if (a > c) {
        temp = a;
        a = c;
        c = temp;
    }
    if (b > c) {
        temp = b;
        b = c;
        c = temp;
    }
}

int main() {
    int num1, num2, num3;

    // Solicitamos los tres números enteros al usuario
    cout << "Ingrese el primer número: ";
    cin >> num1;
    cout << "Ingrese el segundo número: ";
    cin >> num2;
    cout << "Ingrese el tercer número: ";
    cin >> num3;

    // Llamamos a la función para ordenar los números
    ordenar(num1, num2, num3);

    // Imprimimos los números ordenados en forma ascendente
    cout << "Los números ordenados en forma ascendente son: " << num1 << ", " << num2 << ", " << num3 << endl;

    return 0;
}