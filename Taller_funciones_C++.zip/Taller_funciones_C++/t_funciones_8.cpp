#include <iostream>
using namespace std;

void gradosARadianes() {
    float grados, radianes;
    cout << "Ingrese los grados: ";
    cin >> grados;
    radianes = grados * 3.14159 / 180;
    cout << grados << " grados = " << radianes << " radianes" << endl;
}

void celsiusAFahrenheit() {
    float celsius, fahrenheit;
    cout << "Ingrese los grados Celsius: ";
    cin >> celsius;
    fahrenheit = (celsius * 9/5) + 32;
    cout << celsius << " grados Celsius = " << fahrenheit << " grados Fahrenheit" << endl;
}

void metrosAPulgadas() {
    float metros, pulgadas;
    cout << "Ingrese los metros: ";
    cin >> metros;
    pulgadas = metros * 39.37;
    cout << metros << " metros = " << pulgadas << " pulgadas" << endl;
}

void horasASegundos() {
    float horas, segundos;
    cout << "Ingrese las horas: ";
    cin >> horas;
    segundos = horas * 3600;
    cout << horas << " horas = " << segundos << " segundos" << endl;
}

int main() {
    int opcion;
    do {
        cout << "Conversiones" << endl;
        cout << "1. Grados a radianes" << endl;
        cout << "2. Grados Celsius a Fahrenheit" << endl;
        cout << "3. Metros a pulgadas" << endl;
        cout << "4. Horas a segundos" << endl;
        cout << "5. Salir" << endl;
        cout << "Ingrese una opcion: ";
        cin >> opcion;
        switch(opcion) {
            case 1:
                gradosARadianes();
                break;
            case 2:
                celsiusAFahrenheit();
                break;
            case 3:
                metrosAPulgadas();
                break;
            case 4:
                horasASegundos();
                break;
            case 5:
                cout << "Saliendo del programa..." << endl;
                break;
            default:
                cout << "Opcion invalida. Intente de nuevo." << endl;
        }
    } while(opcion != 5);
    return 0;
}