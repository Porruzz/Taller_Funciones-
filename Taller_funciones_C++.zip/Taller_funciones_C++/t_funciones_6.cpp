#include <iostream>
using namespace std;

float calcularIVA(float costo, float porcentajeIVA) {
    float iva = costo * porcentajeIVA / 100;
    return iva;
}

int main() {
    float costo, porcentajeIVA, iva;

    // Caso 1
    cout << "Ingrese el costo del producto: ";
    cin >> costo;
    cout << "Ingrese el porcentaje del IVA: ";
    cin >> porcentajeIVA;
    iva = calcularIVA(costo, porcentajeIVA);
    cout << "El IVA del producto es: " << iva << endl;

    // Caso 2
    cout << "Ingrese el costo del producto: ";
    cin >> costo;
    cout << "Ingrese el porcentaje del IVA: ";
    cin >> porcentajeIVA;
    iva = calcularIVA(costo, porcentajeIVA);
    cout << "El IVA del producto es: " << iva << endl;

    // Caso 3
    cout << "Ingrese el costo del producto: ";
    cin >> costo;
    cout << "Ingrese el porcentaje del IVA: ";
    cin >> porcentajeIVA;
    iva = calcularIVA(costo, porcentajeIVA);
    cout << "El IVA del producto es: " << iva << endl;

    return 0;
}