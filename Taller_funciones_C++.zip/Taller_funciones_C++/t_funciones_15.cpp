#include <iostream>
using namespace std;

// Función para leer los números
void leerNumeros(int& num1, int& num2, int& num3) {
    cout << "Ingrese el primer número: ";
    cin >> num1;
    cout << "Ingrese el segundo número: ";
    cin >> num2;
    cout << "Ingrese el tercer número: ";
    cin >> num3;
}

// Función para obtener el mayor número
int obtenerMayor(int num1, int num2, int num3) {
    int mayor = num1;
    if (num2 > mayor) {
        mayor = num2;
    }
    if (num3 > mayor) {
        mayor = num3;
    }
    return mayor;
}

// Función para escribir el mayor número
void escribirMayor(int mayor) {
    cout << "El mayor número es: " << mayor << endl;
}

int main() {
    int num1, num2, num3;
    leerNumeros(num1, num2, num3);
    int mayor = obtenerMayor(num1, num2, num3);
    escribirMayor(mayor);
    return 0;
}