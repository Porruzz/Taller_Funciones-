#include <iostream>

using namespace std;

void caidaLibre(int tiempo) {
    const float g = 9.8; // Aceleración de la gravedad en m/s^2
    float distancia;
    for (int i = 1; i <= tiempo; i++) {
        distancia = (g * i * i) / 2;
        cout << "Distancia recorrida en el segundo " << i << ": " << distancia << " km" << endl;
    }
}

int main() {
    int tiempo = 10;
    caidaLibre(tiempo);
    return 0;
}