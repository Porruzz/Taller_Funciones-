#include <iostream>

using namespace std;

int sumatoria(int n) {
    int suma = 0;
    for (int i = 1; i <= n; i++) {
        suma += i;
    }
    return suma;
}

int producto(int n) {
    int prod = 1;
    for (int i = 1; i <= n; i++) {
        prod *= i;
    }
    return prod;
}

int main() {
    int opcion, n;
    do {
        cout << "Menu de opciones" << endl;
        cout << "1. Sumatoria" << endl;
        cout << "2. Producto" << endl;
        cout << "- Digite opcion: ";
        cin >> opcion;
        switch (opcion) {
            case 1:
                cout << "Digite el valor de N: ";
                cin >> n;
                cout << "La sumatoria de 1 hasta " << n << " es: " << sumatoria(n) << endl;
                break;
            case 2:
                cout << "Digite el valor de N: ";
                cin >> n;
                cout << "El producto de 1 hasta " << n << " es: " << producto(n) << endl;
                break;
            default:
                cout << "Opcion invalida. Intente de nuevo." << endl;
                break;
        }
    } while (opcion != 1 && opcion != 2);
    return 0;
}