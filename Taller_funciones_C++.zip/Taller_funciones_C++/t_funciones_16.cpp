#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// Función para el juego de cara o sello
void cara_o_sello() {
    int moneda = rand() % 2;
    int eleccion;
    cout << "Cara o sello? (0 para cara, 1 para sello): ";
    cin >> eleccion;
    if (eleccion == moneda) {
        cout << "¡Acertaste! La moneda cayó en ";
        if (moneda == 0) {
            cout << "cara." << endl;
        } else {
            cout << "sello." << endl;
        }
    } else {
        cout << "Lo siento, perdiste. La moneda cayó en ";
        if (moneda == 0) {
            cout << "cara." << endl;
        } else {
            cout << "sello." << endl;
        }
    }
}

// Función para el juego de adivinar el número del dado
void adivinar_dado() {
    srand(time(NULL));
    int dado = rand() % 6 + 1;
    int eleccion;
    cout << "Adivina el número del dado (1-6): ";
    cin >> eleccion;
    if (eleccion == dado) {
        cout << "¡Acertaste! El número del dado era " << dado << "." << endl;
    } else {
        cout << "Lo siento, perdiste. El número del dado era " << dado << "." << endl;
    }
}

// Función para el juego del número mágico
void numero_magico() {
    srand(time(NULL));
    int numero_magico = rand() % 100 + 1;
    int eleccion;
    int intentos = 0;
    do {
        cout << "Adivina el número mágico (1-100): ";
        cin >> eleccion;
        intentos++;
        if (eleccion < numero_magico) {
            cout << "El número mágico es mayor." << endl;
        } else if (eleccion > numero_magico) {
            cout << "El número mágico es menor." << endl;
        }
    } while (eleccion != numero_magico);
    cout << "¡Acertaste! El número mágico era " << numero_magico << "." << endl;
    cout << "Lo adivinaste en " << intentos << " intentos." << endl;
}

int main() {
    int opcion;
    do {
        cout << "Menu" << endl;
        cout << "1. Cara o sello" << endl;
        cout << "2. Adivinar el número del dado" << endl;
        cout << "3. Número mágico" << endl;
        cout << "0. Salir" << endl;
        cout << "Elige una opción: ";
        cin >> opcion;
        switch (opcion) {
            case 1:
                cara_o_sello();
                break;
            case 2:
                adivinar_dado();
                break;
            case 3:
                numero_magico();
                break;
            case 0:
                cout << "Adiós." << endl;
                break;
            default:
                cout << "Opción inválida." << endl;
                break;
        }
    } while (opcion != 0);
    return 0;
}   