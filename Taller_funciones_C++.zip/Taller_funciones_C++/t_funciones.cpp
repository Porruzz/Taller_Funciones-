#include <iostream>
#include <cmath>

using namespace std;

// Función para calcular el cubo de un número real
double cubo(double num) {
    return pow(num, 3);
}

int main() {
    double num;

    // Solicitamos el número real al usuario
    cout << "Ingrese un número real: ";
    cin >> num;

    // Calculamos el cubo del número utilizando la función cubo
    double cubo_num = cubo(num);

    // Imprimimos el resultado
    cout << "El cubo de " << num << " es: " << cubo_num << endl;

    return 0;
}