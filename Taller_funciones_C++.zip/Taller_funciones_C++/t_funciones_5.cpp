#include <iostream>
using namespace std;

// Función para calcular el salario básico
float calcularSalario(float horas, float valorHora) {
    float salario = 0;
    if (horas <= 180) {
        salario = horas * valorHora;
    } else {
        salario = 180 * valorHora + (horas - 180) * valorHora * 1.5;
    }
    return salario;
}

// Función para calcular el subsidio familiar
float calcularSubsidio(int numHijos) {
    float subsidio = 0;
    if (numHijos < 3) {
        subsidio = numHijos * 30000;
    } else {
        subsidio = numHijos * 20000;
    }
    return subsidio;
}

// Función para calcular la bonificación
float calcularBonificacion(char tipoContrato) {
    float bonificacion = 0;
    switch (tipoContrato) {
        case 'I':
            bonificacion = 200000;
            break;
        case 'D':
            bonificacion = 150000;
            break;
        case 'P':
            bonificacion = 100000;
            break;
        default:
            cout << "Tipo de contrato inválido" << endl;
            break;
    }
    return bonificacion;
}

int main() {
    int opcion;
    float horas, valorHora, salario;
    int numHijos;
    char tipoContrato;
    float subsidio, bonificacion;

    do {
        cout << "NOMINA" << endl;
        cout << "1. Salario Basico" << endl;
        cout << "2. Subsidio Familiar" << endl;
        cout << "3. Bonificacion" << endl;
        cout << "4. Salir" << endl;
        cout << "Digite opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Digite el numero de horas trabajadas: ";
                cin >> horas;
                cout << "Digite el valor de la hora: ";
                cin >> valorHora;
                salario = calcularSalario(horas, valorHora);
                cout << "El salario básico es: $" << salario << endl;
                break;
            case 2:
                cout << "Digite el numero de hijos: ";
                cin >> numHijos;
                subsidio = calcularSubsidio(numHijos);
                cout << "El subsidio familiar es: $" << subsidio << endl;
                break;
            case 3:
                cout << "Digite el tipo de contrato (I, D o P): ";
                cin >> tipoContrato;
                bonificacion = calcularBonificacion(tipoContrato);
                cout << "La bonificación es: $" << bonificacion << endl;
                break;
            case 4:
                cout << "Saliendo del programa..." << endl;
                break;
            default:
                cout << "Opcion invalida" << endl;
                break;
        }
    } while (opcion != 4);

    return 0;
}